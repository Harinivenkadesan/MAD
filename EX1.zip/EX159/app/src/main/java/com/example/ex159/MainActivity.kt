package com.example.ex159

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView
    private lateinit var buttonChangeFont: Button
    private lateinit var buttonChangeColor: Button
    private lateinit var buttonShowToast: Button

    // List of colors
    private val colors = listOf(
        "#FF5722", // Deep Orange
        "#4CAF50", // Green
        "#2196F3", // Blue
        "#9C27B0", // Purple
        "#FFC107", // Amber
        "#E91E63"  // Pink
    )

    // List of typefaces (only built-in here)
    private val typefaces = listOf(
        Typeface.SERIF,
        Typeface.SANS_SERIF,
        Typeface.MONOSPACE,
        Typeface.DEFAULT_BOLD
    )

    private var colorIndex = 0
    private var fontIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.textView)
        buttonChangeFont = findViewById(R.id.buttonChangeFont)
        buttonChangeColor = findViewById(R.id.buttonChangeColor)
        buttonShowToast = findViewById(R.id.buttonShowToast)

        buttonChangeFont.setOnClickListener {
            // Change font cyclically
            val typeface = typefaces[fontIndex % typefaces.size]
            textView.typeface = typeface
            fontIndex++
        }

        buttonChangeColor.setOnClickListener {
            // Change color cyclically
            val color = Color.parseColor(colors[colorIndex % colors.size])
            textView.setTextColor(color)
            colorIndex++
        }

        buttonShowToast.setOnClickListener {
            Toast.makeText(this, "Button Pressed!", Toast.LENGTH_SHORT).show()
        }
    }
}
