package com.example.ex173

import android.content.Context
import android.graphics.*
import android.view.View

class DrawView(context: Context) : View(context) {

    private val circlePaint = Paint().apply {
        color = Color.RED
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val ellipsePaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val rectanglePaint = Paint().apply {
        color = Color.BLUE
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.BLACK
        textSize = 60f
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val width = width
        val height = height

        // Draw Circle (Top Center)
        val circleRadius = 150f
        canvas.drawCircle(width / 2f, 200f, circleRadius, circlePaint)

        // Draw Ellipse (Center Left)
        val ellipseRect = RectF(50f, height / 2f - 100f, 350f, height / 2f + 100f)
        canvas.drawOval(ellipseRect, ellipsePaint)

        // Draw Rectangle (Center Right)
        val rectLeft = width - 350f
        val rectTop = height / 2f - 150f
        val rectRight = width - 50f
        val rectBottom = height / 2f + 150f
        canvas.drawRect(rectLeft, rectTop, rectRight, rectBottom, rectanglePaint)

        // Draw Text (Bottom Center)
        canvas.drawText("Graphical Primitives", width / 2f, height - 100f, textPaint)
    }
}
