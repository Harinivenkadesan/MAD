package com.example.ex175

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var editTextCGPA: EditText
    private lateinit var buttonSave: Button

    private val STORAGE_PERMISSION_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextName = findViewById(R.id.editTextName)
        editTextCGPA = findViewById(R.id.editTextCGPA)
        buttonSave = findViewById(R.id.buttonSave)

        buttonSave.setOnClickListener {
            if (checkPermission()) {
                saveDataToSDCard()
            } else {
                requestPermission()
            }
        }
    }

    private fun saveDataToSDCard() {
        val name = editTextName.text.toString()
        val cgpa = editTextCGPA.text.toString()

        if (name.isEmpty() || cgpa.isEmpty()) {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show()
            return
        }

        if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED) {
            val folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            if (!folder.exists()) {
                folder.mkdirs()
            }
            val file = File(folder, "student_details.txt")
            try {
                val fileOutputStream = FileOutputStream(file, true) // true to append
                val data = "Name: $name, CGPA: $cgpa\n"
                fileOutputStream.write(data.toByteArray())
                fileOutputStream.close()
                Toast.makeText(this, "Data Saved Successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "Error saving data", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "SD Card not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkPermission(): Boolean {
        val write = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val read = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
        return write == PackageManager.PERMISSION_GRANTED && read == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE),
            STORAGE_PERMISSION_CODE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveDataToSDCard()
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
