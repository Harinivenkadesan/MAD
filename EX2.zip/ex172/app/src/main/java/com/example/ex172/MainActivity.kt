package com.example.ex172

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import kotlin.math.*

class MainActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private var lastNumeric: Boolean = false
    private var stateError: Boolean = false
    private var lastDot: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.et_input)
    }

    fun onDigit(view: View) {
        if (stateError) {
            input.setText((view as Button).text)
            stateError = false
        } else {
            input.append((view as Button).text)
        }
        lastNumeric = true
    }

    fun onOperator(view: View) {
        if (lastNumeric && !stateError) {
            input.append((view as Button).text)
            lastDot = false
            lastNumeric = false
        }
    }

    fun onClear(view: View) {
        input.setText("")
        lastNumeric = false
        stateError = false
        lastDot = false
    }

    fun onEqual(view: View) {
        if (lastNumeric && !stateError) {
            val txt = input.text.toString()
            try {
                val result = eval(txt)
                input.setText(result.toString())
                lastDot = true
            } catch (e: Exception) {
                input.setText("Error")
                stateError = true
                lastNumeric = false
            }
        }
    }

    fun onDot(view: View) {
        if (lastNumeric && !stateError && !lastDot) {
            input.append(".")
            lastNumeric = false
            lastDot = true
        }
    }

    fun onFunction(view: View) {
        if (!stateError) {
            val txt = input.text.toString()
            try {
                val number = txt.toDouble()
                val result = when ((view as Button).text) {
                    "sin" -> sin(Math.toRadians(number))
                    "cos" -> cos(Math.toRadians(number))
                    "tan" -> tan(Math.toRadians(number))
                    "log" -> log10(number)
                    "√" -> sqrt(number)
                    "pow" -> number * number
                    "mod" -> number % 2
                    else -> 0.0
                }
                input.setText(result.toString())
                lastDot = true
            } catch (e: Exception) {
                input.setText("Error")
                stateError = true
                lastNumeric = false
            }
        }
    }

    private fun eval(str: String): Double {
        return object : Any() {
            var pos = -1
            var ch = 0

            fun nextChar() {
                ch = if (++pos < str.length) str[pos].code else -1
            }

            fun eat(charToEat: Int): Boolean {
                while (ch == ' '.code) nextChar()
                if (ch == charToEat) {
                    nextChar()
                    return true
                }
                return false
            }

            fun parse(): Double {
                nextChar()
                val x = parseExpression()
                if (pos < str.length) throw RuntimeException("Unexpected: " + str[pos])
                return x
            }

            fun parseExpression(): Double {
                var x = parseTerm()
                while (true) {
                    when {
                        eat('+'.code) -> x += parseTerm()
                        eat('-'.code) -> x -= parseTerm()
                        else -> return x
                    }
                }
            }

            fun parseTerm(): Double {
                var x = parseFactor()
                while (true) {
                    when {
                        eat('*'.code) -> x *= parseFactor()
                        eat('/'.code) -> x /= parseFactor()
                        else -> return x
                    }
                }
            }

            fun parseFactor(): Double {
                if (eat('+'.code)) return parseFactor()
                if (eat('-'.code)) return -parseFactor()

                var x: Double
                val startPos = pos
                if (eat('('.code)) {
                    x = parseExpression()
                    eat(')'.code)
                } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                    while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                    x = str.substring(startPos, pos).toDouble()
                } else {
                    throw RuntimeException("Unexpected: " + ch.toChar())
                }
                return x
            }
        }.parse()
    }
}
