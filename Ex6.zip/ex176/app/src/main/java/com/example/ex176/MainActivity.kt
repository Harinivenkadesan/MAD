package com.example.ex176

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var btnGetInfo: Button
    private lateinit var textViewInfo: TextView
    private val PERMISSION_REQUEST_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnGetInfo = findViewById(R.id.btnGetInfo)
        textViewInfo = findViewById(R.id.textViewInfo)

        btnGetInfo.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    arrayOf(Manifest.permission.READ_PHONE_STATE),
                    PERMISSION_REQUEST_CODE)
            } else {
                showTelephonyInfo()
            }
        }
    }

    private fun showTelephonyInfo() {
        val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        val info = StringBuilder()

        info.append("Network Operator Name: ${tm.networkOperatorName}\n")
        info.append("SIM Operator: ${tm.simOperatorName}\n")
        info.append("Network Country: ${tm.networkCountryIso}\n")
        info.append("SIM Country: ${tm.simCountryIso}\n")
        info.append("Phone Type: ${getPhoneType(tm.phoneType)}\n")
        info.append("Network Type: ${getNetworkType(tm.networkType)}\n")

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            info.append("Line Number: ${tm.line1Number ?: "Unavailable"}\n")
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                info.append("IMEI: ${tm.deviceId ?: "Restricted on Android 10+"}\n")
            } else {
                info.append("IMEI: Not accessible on Android 10+\n")
            }
        }

        textViewInfo.text = info.toString()
    }

    private fun getPhoneType(type: Int): String = when (type) {
        TelephonyManager.PHONE_TYPE_CDMA -> "CDMA"
        TelephonyManager.PHONE_TYPE_GSM -> "GSM"
        TelephonyManager.PHONE_TYPE_SIP -> "SIP"
        TelephonyManager.PHONE_TYPE_NONE -> "None"
        else -> "Unknown"
    }

    private fun getNetworkType(type: Int): String = when (type) {
        TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
        TelephonyManager.NETWORK_TYPE_NR -> "5G"
        TelephonyManager.NETWORK_TYPE_HSPA -> "HSPA"
        TelephonyManager.NETWORK_TYPE_EDGE -> "EDGE"
        TelephonyManager.NETWORK_TYPE_GPRS -> "GPRS"
        else -> "Other"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            showTelephonyInfo()
        } else {
            Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
        }
    }
}
